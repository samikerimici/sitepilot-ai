## Objectif

Décrivez le besoin traité.

## Changements

- 

## Vérifications

- [ ] La syntaxe PHP a été vérifiée.
- [ ] Le changement a été testé sur un environnement WordPress.
- [ ] Aucune clé API ni donnée client n’est incluse.
- [ ] La documentation a été mise à jour si nécessaire.

## Captures ou remarques

Ajoutez les éléments utiles à la relecture.
